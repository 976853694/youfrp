<html lang="en">
	<head>
		<title>403 Forbidden</title>
		<style type="text/css">
			body {
				background: #F1F1F1;
				font-weight: 100 ! important;
				padding: 32px;
			}
			h1 {
				font-weight: 100 ! important;
			}
			logo {
				font-size: 100px;
			}
		</style>
	</head>
	<body>
		<logo>:(</logo>
		<h1>403 Forbidden</h1>
		<p><b>Error:</b> Permission denied</p>
		<p><em>Powered by 内网穿透面板</em></p>
	</body>
</html>