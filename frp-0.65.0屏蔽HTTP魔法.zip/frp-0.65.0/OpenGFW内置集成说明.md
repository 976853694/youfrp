# frp内置OpenGFW流量过滤功能说明

## 概述

OpenGFW流量过滤功能已直接集成到frp服务器源码中，不再是插件形式。可以在用户连接时检测和屏蔽VPN、代理和HTTP流量。

## 功能特性

- ✅ 屏蔽SOCKS代理（SOCKS4/SOCKS5）
- ✅ 屏蔽全加密流量（Shadowsocks、VMess等）
- ✅ 屏蔽Trojan协议
- ✅ 屏蔽WireGuard VPN
- ✅ 屏蔽OpenVPN
- ✅ 屏蔽HTTP流量
- ✅ 保留SSH连接（不屏蔽）
- ✅ 内置开关控制

## 安装步骤

### 1. 添加OpenGFW依赖

在 `go.mod` 文件中添加OpenGFW依赖：

```bash
cd frp-0.65.0
go get github.com/apernet/OpenGFW
go mod tidy
```

### 2. 准备规则文件

将 `block_vpn_http.yaml` 规则文件复制到frp服务器可访问的路径，例如：

```bash
cp conf/block_vpn_http.yaml /etc/frp/block_vpn_http.yaml
```

### 3. 配置frps

在 `frps.toml` 配置文件中添加OpenGFW配置：

```toml
[opengfw]
enabled = true
rulesetPath = "/etc/frp/block_vpn_http.yaml"
logBlocked = true
```

### 4. 编译frps

```bash
go build -o frps ./cmd/frps
```

### 5. 运行frps

```bash
./frps -c frps.toml
```

## 配置说明

### OpenGFW配置项

- `enabled` (可选): 启用或禁用OpenGFW流量过滤，默认为 `false`
  - `true`: 启用流量过滤（需要配置rulesetPath）
  - `false`: 禁用流量过滤（即使配置了其他选项也不会生效）
- `rulesetPath` (必需，当enabled=true时): OpenGFW规则文件路径
  - 可以使用相对路径（相对于frps工作目录）或绝对路径
- `logBlocked` (可选): 是否记录被屏蔽的连接，默认为 `true`

## 工作原理

1. 当用户连接到frp服务器时，OpenGFW会在连接建立后立即检测
2. 读取连接的前8KB数据进行协议分析
3. 使用OpenGFW的分析器检测流量协议（HTTP、SOCKS、VPN等）
4. 根据规则文件中的规则进行匹配
5. 如果匹配到屏蔽规则，连接会被立即关闭
6. 如果启用日志，被屏蔽的连接会被记录

## 注意事项

1. **性能影响**: 流量检测会增加一定的延迟（约5秒超时），建议在测试环境验证性能
2. **误报风险**: 
   - FET检测可能有误报
   - Trojan检测有约1%的误报率
3. **规则热重载**: 目前不支持热重载，修改规则需要重启frps
4. **日志位置**: 被屏蔽的连接日志会输出到frps的标准日志
5. **数据消耗**: 检测会读取连接的前8KB数据，这些数据会被缓冲并在允许连接时恢复

## 规则文件示例

规则文件 `block_vpn_http.yaml` 包含以下规则：

- 屏蔽SOCKS代理
- 屏蔽全加密流量（Shadowsocks、VMess等）
- 屏蔽Trojan协议
- 屏蔽WireGuard VPN
- 屏蔽OpenVPN
- 屏蔽HTTP流量

## 故障排查

如果功能无法正常工作：

1. 检查 `enabled` 是否设置为 `true`
2. 检查规则文件路径是否正确
3. 检查规则文件格式是否正确（YAML格式）
4. 查看frps日志中的错误信息
5. 确认OpenGFW依赖已正确安装

## 示例配置

### 启用OpenGFW

```toml
bindAddr = "0.0.0.0"
bindPort = 7000

auth.method = "token"
auth.token = "your_token_here"

[opengfw]
enabled = true
rulesetPath = "conf/block_vpn_http.yaml"
logBlocked = true
```

### 禁用OpenGFW

```toml
[opengfw]
enabled = false
# 即使配置了其他选项，功能也不会生效
```

### 不配置OpenGFW

如果完全移除 `[opengfw]` 配置段，功能默认禁用。

## 与插件版本的区别

- **内置版本**（当前）: 直接集成在frp源码中，无需插件系统
- **插件版本**（已移除）: 通过frp插件系统加载

内置版本的优势：
- 更简单的配置（无需配置插件操作）
- 更直接的集成（代码层面）
- 更好的性能（减少插件调用开销）


