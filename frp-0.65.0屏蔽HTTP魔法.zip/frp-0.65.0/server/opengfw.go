// Copyright 2024 OpenGFW Integration
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package server

import (
	"context"
	"fmt"
	"io"
	"net"
	"sync"
	"time"

	"github.com/apernet/OpenGFW/analyzer"
	"github.com/apernet/OpenGFW/analyzer/tcp"
	"github.com/apernet/OpenGFW/analyzer/udp"
	"github.com/apernet/OpenGFW/ruleset"
	"github.com/apernet/OpenGFW/ruleset/builtins/geo"

	"github.com/fatedier/frp/pkg/util/log"
	"github.com/fatedier/frp/server/controller" // Import controller for OpengfwRulesetInterface
)

// OpengfwRulesetInterface is defined in server/controller package
// We use controller.OpengfwRulesetInterface here to avoid circular imports

type opengfwRulesetImpl struct {
	ruleset    ruleset.Ruleset
	analyzers  []analyzer.Analyzer
	logBlocked bool
	mu         sync.RWMutex
}

// NewOpenGFWRuleset creates a new OpenGFW ruleset instance
func NewOpenGFWRuleset(rulesetPath string, logBlocked bool) (controller.OpengfwRulesetInterface, error) {
	if rulesetPath == "" {
		return nil, fmt.Errorf("ruleset path is required")
	}

	// Initialize analyzers
	analyzers := []analyzer.Analyzer{
		&tcp.FETAnalyzer{},
		&tcp.HTTPAnalyzer{},
		&tcp.SocksAnalyzer{},
		&tcp.TrojanAnalyzer{},
		&udp.DNSAnalyzer{},
		&udp.OpenVPNAnalyzer{},
		&udp.QUICAnalyzer{},
		&udp.WireGuardAnalyzer{},
	}

	// Load ruleset
	rawRs, err := ruleset.ExprRulesFromYAML(rulesetPath)
	if err != nil {
		return nil, fmt.Errorf("failed to load ruleset: %w", err)
	}

	dialer := &net.Dialer{}
	rsConfig := &ruleset.BuiltinConfig{
		Logger:     &opengfwLogger{logBlocked: logBlocked},
		GeoMatcher: geo.NewGeoMatcher("", ""),
		ProtectedDialContext: func(ctx context.Context, network, address string) (net.Conn, error) {
			return dialer.DialContext(ctx, network, address)
		},
	}

	rs, err := ruleset.CompileExprRules(rawRs, analyzers, nil, rsConfig)
	if err != nil {
		return nil, fmt.Errorf("failed to compile ruleset: %w", err)
	}

	return &opengfwRulesetImpl{
		ruleset:    rs,
		analyzers:  analyzers,
		logBlocked: logBlocked,
	}, nil
}

// CheckConnection analyzes a connection and returns true if it should be blocked
// Note: This reads data from the connection, so the caller needs to handle the consumed data
func (r *opengfwRulesetImpl) CheckConnection(conn net.Conn, timeout time.Duration) (bool, error) {
	r.mu.RLock()
	rs := r.ruleset
	r.mu.RUnlock()

	// Get connection info first
	localAddr := conn.LocalAddr()
	remoteAddr := conn.RemoteAddr()

	var localIP, remoteIP net.IP
	var localPort, remotePort uint16
	var protocol ruleset.Protocol

	if tcpAddr, ok := localAddr.(*net.TCPAddr); ok {
		localIP = tcpAddr.IP
		localPort = uint16(tcpAddr.Port)
		protocol = ruleset.ProtocolTCP
	} else if udpAddr, ok := localAddr.(*net.UDPAddr); ok {
		localIP = udpAddr.IP
		localPort = uint16(udpAddr.Port)
		protocol = ruleset.ProtocolUDP
	} else {
		return false, fmt.Errorf("unsupported address type")
	}

	if tcpAddr, ok := remoteAddr.(*net.TCPAddr); ok {
		remoteIP = tcpAddr.IP
		remotePort = uint16(tcpAddr.Port)
	} else if udpAddr, ok := remoteAddr.(*net.UDPAddr); ok {
		remoteIP = udpAddr.IP
		remotePort = uint16(udpAddr.Port)
	} else {
		return false, fmt.Errorf("unsupported address type")
	}

	// Read a sample of data from the connection for analysis
	// If conn is a peekableConn, it will buffer the data for later consumption
	buffer := make([]byte, 8192)
	conn.SetReadDeadline(time.Now().Add(timeout))
	n, err := conn.Read(buffer)
	if err != nil && err != io.EOF {
		// If we can't read, allow the connection (fail open)
		conn.SetReadDeadline(time.Time{})
		return false, nil
	}
	conn.SetReadDeadline(time.Time{})

	// Create stream info
	info := ruleset.StreamInfo{
		ID:       0, // Would need proper ID generation in production
		Protocol: protocol,
		SrcIP:    remoteIP,
		DstIP:    localIP,
		SrcPort:  remotePort,
		DstPort:  localPort,
		Props:    make(analyzer.CombinedPropMap),
	}

	// If we read data, we need to analyze it using OpenGFW analyzers
	// This is a simplified version - ideally we'd use OpenGFW's full engine
	if n > 0 {
		// Get analyzers for this stream
		_ = rs.Analyzers(info)
		
		// For now, we'll do a basic check
		// In a full implementation, you'd feed the data to analyzers and update Props
		// Then match against the ruleset
		// TODO: Feed buffer[:n] to analyzers and populate info.Props
	}
	
	// Match against ruleset (with current props, which may be empty)
	result := rs.Match(info)
	
	// If blocked, we don't need to restore the data since we're closing the connection
	// If allowed, the caller needs to handle the consumed data
	return result.Action == ruleset.ActionBlock, nil
}

// ReloadRuleset reloads the ruleset from file
func (r *opengfwRulesetImpl) ReloadRuleset(rulesetPath string) error {
	r.mu.Lock()
	defer r.mu.Unlock()

	rawRs, err := ruleset.ExprRulesFromYAML(rulesetPath)
	if err != nil {
		return fmt.Errorf("failed to load ruleset: %w", err)
	}

	dialer := &net.Dialer{}
	rsConfig := &ruleset.BuiltinConfig{
		Logger:     &opengfwLogger{logBlocked: r.logBlocked},
		GeoMatcher: geo.NewGeoMatcher("", ""),
		ProtectedDialContext: func(ctx context.Context, network, address string) (net.Conn, error) {
			return dialer.DialContext(ctx, network, address)
		},
	}

	rs, err := ruleset.CompileExprRules(rawRs, r.analyzers, nil, rsConfig)
	if err != nil {
		return fmt.Errorf("failed to compile ruleset: %w", err)
	}

	r.ruleset = rs
	return nil
}

func (r *opengfwRulesetImpl) Close() error {
	// Cleanup if needed
	return nil
}

// opengfwLogger implements ruleset.Logger interface
type opengfwLogger struct {
	logBlocked bool
}

func (l *opengfwLogger) Log(info ruleset.StreamInfo, name string) {
	if l.logBlocked {
		log.Infof("[OpenGFW] Rule matched: %s stream=%d src=%s dst=%s",
			name, info.ID, info.SrcString(), info.DstString())
	}
}

func (l *opengfwLogger) MatchError(info ruleset.StreamInfo, name string, err error) {
	log.Warnf("[OpenGFW] Rule match error: %s stream=%d error=%v",
		name, info.ID, err)
}

