// Copyright 2024 OpenGFW Integration
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package proxy

import (
	"io"
	"net"
	"sync"
)

// peekableConn wraps a net.Conn to allow peeking data without consuming it
type peekableConn struct {
	net.Conn
	buf    []byte
	mu     sync.Mutex
	closed bool
}

func newPeekableConn(conn net.Conn) *peekableConn {
	return &peekableConn{
		Conn: conn,
		buf:  make([]byte, 0),
	}
}

func (p *peekableConn) Read(b []byte) (n int, err error) {
	p.mu.Lock()
	defer p.mu.Unlock()

	if p.closed {
		return 0, io.EOF
	}

	// If we have buffered data, return it first
	if len(p.buf) > 0 {
		n = copy(b, p.buf)
		p.buf = p.buf[n:]
		if len(b) > n {
			// Still need more data, read from connection
			var m int
			m, err = p.Conn.Read(b[n:])
			n += m
		}
		return n, err
	}

	// No buffered data, read directly from connection
	return p.Conn.Read(b)
}

func (p *peekableConn) Write(b []byte) (n int, err error) {
	return p.Conn.Write(b)
}

func (p *peekableConn) Close() error {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.closed = true
	return p.Conn.Close()
}

// peek reads data from the connection and buffers it for later consumption
func (p *peekableConn) peek(b []byte) (n int, err error) {
	p.mu.Lock()
	defer p.mu.Unlock()

	if p.closed {
		return 0, io.EOF
	}

	// Read from connection into buffer
	n, err = p.Conn.Read(b)
	if n > 0 {
		// Append to buffer for later consumption
		p.buf = append(p.buf, b[:n]...)
	}
	return n, err
}


