# frp集成OpenGFW流量过滤功能说明

## 概述

本集成将OpenGFW的流量过滤功能添加到frp服务器中，可以在用户连接时检测和屏蔽VPN、代理和HTTP流量。

## 功能特性

- ✅ 屏蔽SOCKS代理（SOCKS4/SOCKS5）
- ✅ 屏蔽全加密流量（Shadowsocks、VMess等）
- ✅ 屏蔽Trojan协议
- ✅ 屏蔽WireGuard VPN
- ✅ 屏蔽OpenVPN
- ✅ 屏蔽HTTP流量
- ✅ 保留SSH连接（不屏蔽）

## 安装步骤

### 1. 添加OpenGFW依赖

在 `go.mod` 文件中添加OpenGFW依赖：

```bash
go get github.com/apernet/OpenGFW
```

### 2. 准备规则文件

将 `block_vpn_http.yaml` 规则文件复制到frp服务器可访问的路径，例如：

```bash
cp block_vpn_http.yaml /etc/frp/block_vpn_http.yaml
```

### 3. 配置frps

在 `frps.toml` 配置文件中添加OpenGFW插件配置：

```toml
[opengfwPlugin]
# 启用OpenGFW插件（设置为false可禁用）
enabled = true
rulesetPath = "/etc/frp/block_vpn_http.yaml"
enabledOps = ["NewUserConn"]
logBlocked = true
```

**注意**: 如果 `enabled = false`，即使配置了其他选项，插件也不会加载。

### 4. 编译frps

```bash
cd frp-0.65.0
go build -o frps ./cmd/frps
```

### 5. 运行frps

```bash
./frps -c frps.toml
```

## 配置说明

### OpenGFWPlugin配置项

- `enabled` (可选): 启用或禁用OpenGFW插件，默认为 `false`
  - `true`: 启用插件（需要配置rulesetPath）
  - `false`: 禁用插件（即使配置了其他选项也不会加载）
- `rulesetPath` (必需，当enabled=true时): OpenGFW规则文件路径
- `enabledOps` (可选): 启用的操作列表，默认为 `["NewUserConn"]`
  - `Login`: 客户端登录时检测
  - `NewProxy`: 创建新代理时检测
  - `NewUserConn`: 新用户连接时检测（推荐）
  - `NewWorkConn`: 新工作连接时检测
- `logBlocked` (可选): 是否记录被屏蔽的连接，默认为 `true`

## 工作原理

1. 当用户连接到frp服务器时，OpenGFW插件会拦截连接
2. 插件使用OpenGFW的分析器检测流量协议
3. 根据规则文件中的规则进行匹配
4. 如果匹配到屏蔽规则，连接会被拒绝
5. 如果启用日志，被屏蔽的连接会被记录

## 注意事项

1. **性能影响**: 流量检测会增加一定的延迟，建议在测试环境验证性能
2. **误报风险**: 
   - FET检测可能有误报
   - Trojan检测有约1%的误报率
3. **规则热重载**: 目前不支持热重载，修改规则需要重启frps
4. **日志位置**: 被屏蔽的连接日志会输出到stderr

## 规则文件示例

规则文件 `block_vpn_http.yaml` 包含以下规则：

- 屏蔽SOCKS代理
- 屏蔽全加密流量（Shadowsocks、VMess等）
- 屏蔽Trojan协议
- 屏蔽WireGuard VPN
- 屏蔽OpenVPN
- 屏蔽HTTP流量

## 故障排查

如果插件无法正常工作：

1. 检查规则文件路径是否正确
2. 检查规则文件格式是否正确（YAML格式）
3. 查看frps日志中的错误信息
4. 确认OpenGFW依赖已正确安装

## 示例配置

完整配置示例请参考 `conf/frps_opengfw.toml`

