# OpenGFW插件开关使用说明

## 开关功能

OpenGFW插件现在支持通过 `enabled` 配置项来启用或禁用功能，无需删除整个配置段。

## 配置方式

### 启用插件

```toml
[opengfwPlugin]
enabled = true                    # 启用插件
rulesetPath = "conf/block_vpn_http.yaml"
enabledOps = ["NewUserConn"]
logBlocked = true
```

### 禁用插件

```toml
[opengfwPlugin]
enabled = false                   # 禁用插件
# 即使配置了其他选项，插件也不会加载
rulesetPath = "conf/block_vpn_http.yaml"
enabledOps = ["NewUserConn"]
logBlocked = true
```

### 不配置插件

如果完全移除 `[opengfwPlugin]` 配置段，插件也不会加载（等同于 `enabled = false`）。

## 行为说明

1. **默认行为**: 如果未设置 `enabled`，默认为 `false`，插件不会加载
2. **启用检查**: 只有当 `enabled = true` 且 `rulesetPath` 已配置时，插件才会加载
3. **禁用时**: 即使配置了 `rulesetPath` 和其他选项，只要 `enabled = false`，插件就不会加载
4. **错误处理**: 如果 `enabled = true` 但 `rulesetPath` 为空，启动时会报错

## 使用场景

### 场景1: 临时禁用功能

当需要临时禁用流量过滤功能时，只需将 `enabled` 设置为 `false`，无需删除配置：

```toml
[opengfwPlugin]
enabled = false  # 临时禁用
rulesetPath = "conf/block_vpn_http.yaml"
# ... 其他配置保留
```

### 场景2: 测试环境

在测试环境中可以快速切换：

```toml
# 测试环境 - 禁用
[opengfwPlugin]
enabled = false

# 生产环境 - 启用
# [opengfwPlugin]
# enabled = true
# rulesetPath = "conf/block_vpn_http.yaml"
```

### 场景3: 条件启用

可以根据环境变量或其他条件动态配置：

```toml
[opengfwPlugin]
enabled = true   # 根据实际情况设置
rulesetPath = "conf/block_vpn_http.yaml"
```

## 验证方法

### 检查插件是否加载

启动frps后，查看日志：

**插件已启用时**:
```
OpenGFW plugin has been registered with ruleset: conf/block_vpn_http.yaml
```

**插件已禁用时**:
- 不会出现上述日志信息
- 或者配置段不存在时也不会有相关日志

### 测试功能

1. 启用插件 (`enabled = true`)，尝试连接被屏蔽的协议，应该被拒绝
2. 禁用插件 (`enabled = false`)，同样的连接应该可以通过

## 注意事项

1. **重启生效**: 修改 `enabled` 配置后需要重启frps才能生效
2. **配置验证**: 如果 `enabled = true` 但 `rulesetPath` 未配置，启动会失败
3. **性能影响**: 禁用插件时不会有任何性能开销
4. **日志输出**: 禁用插件时不会输出任何OpenGFW相关的日志


