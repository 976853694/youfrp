// Copyright 2024 OpenGFW Integration
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package v1

// OpenGFWConfig defines the configuration for built-in OpenGFW traffic filtering
type OpenGFWConfig struct {
	// Enabled enables or disables OpenGFW traffic filtering
	// If false, traffic filtering will be disabled
	Enabled bool `json:"enabled,omitempty"`
	// RulesetPath is the path to the OpenGFW ruleset YAML file
	RulesetPath string `json:"rulesetPath,omitempty"`
	// LogBlocked specifies whether to log blocked connections
	LogBlocked bool `json:"logBlocked,omitempty"`
}

